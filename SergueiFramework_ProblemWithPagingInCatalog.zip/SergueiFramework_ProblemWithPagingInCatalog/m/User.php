<?php

	include_once 'config/db.php';
	class User {		
		public $user_id, $user_login, $user_name, $user_password;

		public function __construct () {
		}

		public function pass ($name, $password) {
			return strrev(md5($name)) . md5($password);
		}

		public function connecting () {
			return new PDO(DRIVER . ':host='. SERVER . ';dbname=' . DB, USERNAME, PASSWORD);
		}

		public function get ($id) {
			$connect = $this->connecting();
			return $connect->query("SELECT * FROM users WHERE id_user = '" . $id . "'")->fetch();
		}

		public function newR ($name, $login, $password) {
			$connect = $this->connecting();
			$user = $connect->query("SELECT * FROM users WHERE user_login = '" . $login . "'")->fetch();
			if (!$user) {
				//echo '1 par - это '.$name;
				//echo '2 par - это '.$login;
				//echo '3 par - это '.$this->pass($name, $password);
				//echo 'out:'."INSERT INTO users () VALUES (`user_name`, `user_login`, `user_password`, `user_last_action`) ('" . $name . "', '" . $login . "', '" . $this->pass($name, $password) . "',null)";
				//$connect->exec("INSERT INTO user (`user_name`, `user_login`, `user_password`, `user_last_action`) VALUES (null, '" . $name . "', '" . $login . "', '" . $this->pass($name, $password) . "')");
				$connect->exec("INSERT INTO users (`user_name`, `user_login`, `user_password`, `user_last_action`) VALUES ('" . $name . "', '" . $login . "', '" . $this->pass($login, $password) . "',null)");
				//'2018-10-12 17:54:20'
				return true;
			} else {
				return false;
			}
		}

		public function login ($login, $password) {
			//session_start();
			$connect = $this->connecting();
			$user = $connect->query("SELECT * FROM users WHERE user_login = '" . $login . "'")->fetch();
			if ($user) {
				//if ($user['user_password'] == $this->pass($user['user_name'], strip_tags($user_password))) {
				if ($user['user_password'] == $this->pass($login, strip_tags($password))) {
					$_SESSION["user_id"] = $user['id_user'];	
					$_SESSION["user_name"] = $user['user_name'];
					$_SESSION["user_login"] = $user['user_login'];	
					$username = $user['user_name'];
					$userlogin = $user['user_login'];
					//print_r ($_SESSION);
    				return 'Добро пожаловать в систему, ' . $user['user_name'] . '!';
				} else {
					return 'Пароль не верный!';
				}
			} else {
				return 'Пользователь с таким логином не зарегистрирован!';
			}
		}

		public function logout () {
			if (isset($_SESSION["user_id"])) {
				$_SESSION["user_id"]=null;
				session_destroy();
				return true;
			} 
			return false;			
		}
	}
?>