<h3><?php if(isset($text)){echo $text;}?></h3>
<br>
<form method="post">
	<?php if(isset($basket_total_sum_text)){echo $basket_total_sum_text;}?>
</form>