<?php
	include_once 'm/Basket.php';

	class C_Basket extends C_Base {
		
		public function action_empty() {
			$this->title .= '::Просмотр корзины товаров';
			$basket_total_sum_text = "Пожалуйста, авторизуйтесь в системе или выберите товар!<br><br>";
			$this->content = $this->Template('v/b_empty.php', array('basket_total_sum_text' => $basket_total_sum_text));
		}
		public function action_view() {
			$this->title .= '::Просмотр корзины товаров';
			$new_basket = new Basket();
			$basket_text="";
			$basket_total_sum_text="";
			if (isset($_SESSION["user_id"])) {
			    $user_id = $_SESSION['user_id'];
				$goods_qty = $new_basket->getqty();
				$result = $new_basket->get($user_id);
				$s='';
				$basket_total_sum_text= "Общая сумма: ";
				$sum=0;	
				while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
					$s='<tr align=center><td>'.$row["num"].'</td><td><a href="index.php?c=item&act=view&num='.$row["id_good"].'"><img alt="Букет #'.$row["id_good"].'" width=65 src="img/'.$row["id_good"].'.jpg" /></a></td><td><i>'.$row["name"].'</i></td><td>'.$row["price"].'.00 руб</td></tr>';
					$basket_text=$basket_text.$s;	
				
					$sum=$sum+($row["num"]*$row["price"]);
				}	
				if ($sum==0) { 
					$basket_total_sum_text="Ваша корзина пуста!";
					$this->content = $this->Template('v/b_empty.php', array('basket_total_sum_text' => $basket_total_sum_text));
				}
				else {
					$basket_total_sum_text = $basket_total_sum_text.$sum.".00 руб<br><br>";
					$this->content = $this->Template('v/b_view.php', array('basket_total_sum_text' => $basket_total_sum_text, 'basket_text' => $basket_text));
					if($this->isPost()) {
						if (isset($_POST['toorder'])) {
							$result = $new_basket->makeorder($user_id, $sum);
							if ($result) {
								$basket_total_sum_text = "Ваш заказ принят! Ваша корзина пуста.<br><br>";
								$this->content = $this->Template('v/b_empty.php', array('basket_total_sum_text' => $basket_total_sum_text)); 	
							}
							else {
								$basket_total_sum_text = "Ошибка принятия заказа! Пожалуйста, свяжитесь с нами!<br><br>";
								$this->content = $this->Template('v/b_empty.php', array('basket_total_sum_text' => $basket_total_sum_text)); 									
							}								
						}
					}
				}				
			}
			else {
				$basket_total_sum_text = "Пожалуйста, авторизуйтесь в системе или выберите товар!<br><br>";
			    $this->content = $this->Template('v/b_empty.php', array('basket_total_sum_text' => $basket_total_sum_text)); 				
			}							
		}
		
	}
?>