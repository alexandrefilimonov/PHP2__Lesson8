<?php
	include_once 'm/Catalog.php';
	include_once 'm/Item.php';
	include_once 'm/Basket.php';
	class C_Catalog extends C_Base {
		
		public function action_view() {
			static $limit; 
			$this->title .= '::Просмотр каталога';
			$new_catalog = new Catalog();
			$catalog_text='';
			$goods_qty = $new_catalog->getqty();
			
			if (isset($_GET["page"])) {
				$page=1;
				$limit=4*$_GET["page"];
			}	
			else {
				$page =++$_GET["page"];	
				$limit+=4;
			}
			$result = $new_catalog->get($limit);
			$s='';

			while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
				$s='<tr align=center><td>'.$row["id_good"].'</td><td><a href="index.php?c=item&act=view&num='.$row["id_good"].'"><img alt="Букет #'.$row["id_good"].'" width=65 src="img/'.$row["id_good"].'.jpg" /></a></td><td><i>'.$row["name"].'</i></td><td>'.$row["price"].'.00 руб</td><td><input type="submit" id="'.$row["id_good"].'" name="item'.$row["id_good"].'" value="Добавить в корзину"></td></tr>';
				$catalog_text=$catalog_text.$s;			
			}
			$this->content = $this->Template('v/c_view.php', array('catalog_text' => $catalog_text));
			if($this->isPost()) {
				for ($x = 1; $x <= $goods_qty[0]; $x++) {
					if (isset($_POST['item'.$x])) {
						if (isset($_SESSION["user_id"])) {
							$user_id = $_SESSION["user_id"];
							$new_item = new Item();
							$new_basket = new Basket();
							$result_adding = $new_basket->add_to_basket($x, $user_id);
							if ($result_adding) {
								$message = "Букет #".$x." добавлен в вашу корзину! Вы можете посмотреть содержимое вашей корзины, кликнув «Корзина» в главном меню.<br><br>";
							}
							else {
								$message = "Не удалось добавить букет #".$x." в корзину!";
							}
						}
						else {
							$message = "Пожалуйста, авторизуйтесь в системе прежде чем добавлять букет #".$x." в корзину!<br><br>";
						} 
						$new_catalog = new Catalog();
						$catalog_text='';
						$result = $new_catalog->get($limit);
						$s='';
						while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							$s='<tr align=center><td>'.$row["id_good"].'</td><td><a href="img/1.jpg" target="_new"><img alt="Букет #'.$row["id_good"].'" width=65 src="img/'.$row["id_good"].'.jpg" /></a></td><td><i>'.$row["name"].'</i></td><td>'.$row["price"].'.00 руб</td><td><input type="submit" id="'.$row["id_good"].'" name="item'.$row["id_good"].'" value="Добавить в корзину"></td></tr>';
							$catalog_text=$catalog_text.$s;		
						}						
						$this->content = $this->Template('v/c_add.php', array('message_text' => $message, 'catalog_text' => $catalog_text));
					} 
					else {
						//echo "No Button Add to basket was not submitted!";
					}
				}
			}
		}
			
		public function action_add(){
			$this->title .= '::Добавить в корзину';
		
			if($this->isPost())
			{
				echo "Get exists";
				text_set($_POST['text']);
				header('location: index.php');
				exit();
			}
			$text = text_get();
			$this->content = $this->Template('v/v_add.php', array('text' => $text));		
		}
	}
?>